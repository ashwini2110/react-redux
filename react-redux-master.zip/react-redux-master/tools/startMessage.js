import colors from 'colors';

/*eslint-disable no-console */

console.log('Starting app...'.green);
