STARTER KIT FOR BUILDING APPLICATION USING REACT

Get Started

1.Install Node.

2.Clone this repository-https://github.com/berdesourabh/react-start.git

3.Type cd react-start

4.Install Node packages- npm install.

5.Run the app - npm start.
